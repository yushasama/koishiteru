# Scribble Render

A standalone, lightweight React library for rendering beautiful Markdown with advanced features like:

- ✨ **KaTeX Math** - Beautiful mathematical equations
- 📊 **Mermaid Diagrams** - Flow charts, sequence diagrams, and more
- 🎨 **Syntax Highlighting** - Powered by Shiki (VS Code quality)
- 🌈 **Beautiful Themes** - Multiple pre-built themes
- 🚀 **Zero Editor Dependencies** - Just pure rendering
- ⚡ **Next.js Ready** - Works seamlessly with Next.js 13+ App Router and Pages Router

## Installation

```bash
npm install scribble-render
# or
yarn add scribble-render
# or
pnpm add scribble-render
```

## Quick Start

```tsx
import { ScribbleRender } from 'scribble-render'
import 'scribble-render/dist/index.css' // Import styles

function App() {
  const markdown = `
# Hello World

This is **bold** and this is *italic*.

## Math Equations
Inline math: $E = mc^2$

Block math:
$$
\\int_{-\\infty}^{\\infty} e^{-x^2} dx = \\sqrt{\\pi}
$$

## Code with Syntax Highlighting
\`\`\`javascript
function greet(name) {
  console.log(\`Hello, \${name}!\`)
}
\`\`\`

## Mermaid Diagram
\`\`\`mermaid
graph LR
  A[Start] --> B[Process]
  B --> C[End]
\`\`\`
  `

  return (
    <ScribbleRender 
      content={markdown}
      theme="GitHub Dark"
      codeTheme="github-dark"
    />
  )
}
```

## Next.js Compatibility

✅ **Fully compatible with Next.js 13+ App Router and Pages Router**

This library uses dynamic imports for Shiki and works seamlessly with Next.js:

```tsx
// app/page.tsx or pages/index.tsx
import { ScribbleRender } from 'scribble-render'
import 'scribble-render/dist/index.css'

export default function Page() {
  return <ScribbleRender content="# Hello Next.js!" theme="Tokyo Night" />
}
```

👉 **See [NEXTJS.md](./NEXTJS.md) for complete Next.js integration guide**

## API

### `ScribbleRender` Component

#### Props

| Prop | Type | Default | Description |
|------|------|---------|-------------|
| `content` | `string` | *required* | Markdown content to render |
| `theme` | `string \| Theme` | `"GitHub Dark"` | Theme name or custom theme object |
| `codeTheme` | `string` | `"github-dark"` | Shiki theme for syntax highlighting |
| `className` | `string` | `""` | Custom CSS class name |
| `loadMermaid` | `boolean` | `true` | Auto-load Mermaid CDN script |

#### Available Themes

- `"GitHub Dark"`
- `"GitHub Light"`
- `"Tokyo Night"`
- `"Nord"`
- `"Dracula"`
- `"Monokai"`
- `"Catppuccin Mocha"`
- `"Rosé Pine"`

#### Available Code Themes (Shiki)

All Shiki bundled themes are supported, including:
- `github-dark`, `github-light`
- `nord`, `tokyo-night`
- `dracula`, `monokai`
- `one-dark-pro`, `night-owl`
- `catppuccin-mocha`, `rose-pine`
- And many more...

### Custom Theme

```tsx
import { ScribbleRender, type Theme } from 'scribble-render'

const customTheme: Theme = {
  name: 'My Theme',
  background: '#1a1a1a',
  text: '#ffffff',
  accent: '#ff6b6b',
  codeBackground: '#2a2a2a',
  codeText: '#f0f0f0',
  border: '#444444',
  shadow: 'rgba(0, 0, 0, 0.3)'
}

<ScribbleRender content={markdown} theme={customTheme} />
```

## Advanced Usage

### Using Individual Components

If you need more control, you can use individual components:

```tsx
import { MarkdownRenderer, CodeRenderer, MermaidRenderer } from 'scribble-render'

// Just markdown rendering
<MarkdownRenderer 
  content={markdown}
  theme={theme}
  codeTheme="nord"
/>

// Just code rendering
<CodeRenderer 
  code="const x = 42;"
  language="javascript"
  theme={theme}
  codeTheme="github-dark"
/>

// Just mermaid diagrams
<MermaidRenderer code="graph TD; A-->B;" />
```

### Using Hooks

```tsx
import { useShiki, useMermaid } from 'scribble-render'

// Syntax highlighting hook
const { html, loading, error } = useShiki(code, 'javascript', 'github-dark')

// Mermaid rendering hook
const containerRef = useRef<HTMLDivElement>(null)
useMermaid(containerRef, 'graph TD; A-->B;')
```

## Features

### Markdown Support

- GitHub Flavored Markdown (GFM)
- Tables
- Task lists
- Strikethrough
- Autolinks
- And more...

### Math Rendering

Powered by KaTeX:
- Inline math: `$...$`
- Block math: `$$...$$`
- Custom macros supported

### Mermaid Diagrams

Supports all Mermaid diagram types:
- Flowcharts
- Sequence diagrams
- Class diagrams
- State diagrams
- Gantt charts
- Pie charts
- And more...

### Syntax Highlighting

Powered by Shiki (same engine as VS Code):
- Accurate, beautiful syntax highlighting
- 50+ languages supported
- 30+ themes available
- Web Worker based (non-blocking)

## Browser Support

- Modern browsers (Chrome, Firefox, Safari, Edge)
- No IE11 support

## License

MIT

## Credits

Built with:
- [React Markdown](https://github.com/remarkjs/react-markdown)
- [KaTeX](https://katex.org/)
- [Mermaid](https://mermaid.js.org/)
- [Shiki](https://shiki.matsu.io/)

